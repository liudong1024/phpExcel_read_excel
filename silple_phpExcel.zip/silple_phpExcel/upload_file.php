<?php
ini_set('display_errors',1);            //错误信息
ini_set('display_startup_errors',1);    //php启动错误信息
error_reporting(-1);
ini_set('error_log', 'error_log.txt'); //将出错信息输出到一个文本文件
error_reporting(E_ALL^E_NOTICE);
include 'PHPExcel_1.8.0_doc/Classes/PHPExcel.php';
include 'PHPExcel_1.8.0_doc/Classes/PHPExcel/Reader/Excel5.php';
include 'PHPExcel_1.8.0_doc/Classes/PHPExcel/IOFactory.php';



if (! empty ( $_FILES ['file_stu'] ['name'] ))
{

    $tmp_file = $_FILES ['file_stu'] ['tmp_name'];
    $file_types = explode ( ".", $_FILES ['file_stu'] ['name'] );
    $file_type = $file_types [count ( $file_types ) - 1];
    /*判别是不是.xls文件，判别是不是excel文件*/
    if (strtolower ( $file_type ) != "xls")
    {
        $this->error ( '不是Excel文件，重新上传' );
    }
    /*设置上传路径*/
    $savePath = './Excel/';
    /*以时间来命名上传的文件*/
    $str = date ( 'Ymdhis' );
    $file_name = $str . "." . $file_type;
    /*是否上传成功*/
    if (! copy ( $tmp_file, $savePath . $file_name ))
    {
        $this->error ( '上传失败' );
    }
    $PHPExcel=new \PHPExcel();
    $PHPReader=new \PHPExcel_Reader_Excel5();
    //获取表中的第一个工作表，如果要获取第二个，把0改为1，依次类推


    $reader = PHPExcel_IOFactory::createReader('Excel5'); //设置以Excel5格式(Excel97-2003工作簿)
    $PHPExcel = $reader->load($savePath . $file_name); // 载入excel文件
    $sheet = $PHPExcel->getSheet(0); // 读取第一個工作表
    $highestRow = $sheet->getHighestRow(); // 取得总行数
    $colsNum = $sheet->getHighestColumn(); // 取得总列数
    $highestColumm= PHPExcel_Cell::columnIndexFromString($colsNum); //字母列转换为数字列 如:AA变为27

    /** 循环读取每个单元格的数据 */
    for ($row = 1; $row <= $highestRow; $row++){//行数是以第1行开始
        for ($column = 0; $column < $highestColumm; $column++) {//列数是以第0列开始
            $columnName = PHPExcel_Cell::stringFromColumnIndex($column);
            echo $row;
            echo $columnName.$row.":".$sheet->getCellByColumnAndRow($column, $row)->getCalculatedValue()."<br />";
        }
    }


//         var_dump($arr); echo "<br />";
//    foreach ( $arr as $k => $v ) {
//        // 数据处理
//    }


    /*
       *对上传的Excel数据进行处理生成编程数据,这个函数会在下面第三步的ExcelToArray类中
      注意：这里调用执行了第三步类里面的read函数，把Excel转化为数组并返回给$res,再进行数据库写入
    */
//    $res = Service ( 'ExcelToArray' )->read ( $savePath . $file_name );
    /*
         重要代码 解决Thinkphp M、D方法不能调用的问题
         如果在thinkphp中遇到M 、D方法失效时就加入下面一句代码
     */
    //spl_autoload_register ( array ('Think', 'autoload' ) );
    /*对生成的数组进行数据库的写入*/
//    foreach ( $res as $k => $v )
//    {
//        if ($k != 0)
//        {
//            $data ['uid'] = $v [0];
//            $data ['password'] = sha1 ( '111111' );
//            $data ['email'] = $v [1];
//            $data ['uname'] = $v [3];
//            $data ['institute'] = $v [4];
//            $result = M ( 'user' )->add ( $data );
//            if (! $result)
//            {
//                $this->error ( '导入数据库失败' );
//            }
//        }
//    }
}
?>
