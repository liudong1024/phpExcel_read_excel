<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Excel文件上传</title>
</head>
<body>

<form method="post" action="upload_file.php" enctype="multipart/form-data">
    <h3>导入Excel表：</h3><input  type="file" name="file_stu" />
    <input type="submit"  value="导入" />
</form>

</body>
</html>